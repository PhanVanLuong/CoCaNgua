
package com.example.cocangua
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
