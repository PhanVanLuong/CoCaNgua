
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() => runApp(MyApp());

class Player {
  String name;
  int da;
  int biDa;

  Player(this.name,{this.da=0,this.biDa=0});

  int get tong => da + biDa;

  Map<String,dynamic> toJson()=>{'name':name,'da':da,'biDa':biDa};
  static Player fromJson(Map<String,dynamic> j)=>Player(j['name'],da:j['da'],biDa:j['biDa']);
}

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return MaterialApp(debugShowCheckedModeBanner:false,home:ScorePage());
  }
}

class ScorePage extends StatefulWidget{
  @override
  _ScorePageState createState()=>_ScorePageState();
}

class _ScorePageState extends State<ScorePage>{

  List<Player> players=[Player("Nguoi 1"),Player("Nguoi 2")];

  @override
  void initState(){super.initState();load();}

  save() async{
    final p=await SharedPreferences.getInstance();
    p.setString("players",jsonEncode(players.map((e)=>e.toJson()).toList()));
  }

  load() async{
    final p=await SharedPreferences.getInstance();
    var s=p.getString("players");
    if(s!=null){
      var list=jsonDecode(s);
      setState(()=>players=list.map<Player>((e)=>Player.fromJson(e)).toList());
    }
  }

  add(){
    if(players.length<4){
      setState(()=>players.add(Player("Nguoi ${players.length+1}")));
      save();
    }
  }

  reset(){
    setState((){
      for(var p in players){p.da=0;p.biDa=0;}
    });
    save();
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar:AppBar(title:Text("Co Ca Ngua"),actions:[IconButton(icon:Icon(Icons.refresh),onPressed:reset)]),
      floatingActionButton:FloatingActionButton(onPressed:add,child:Icon(Icons.add)),
      body:ListView(children:players.map((p)=>Card(
        margin:EdgeInsets.all(10),
        child:Padding(
          padding:EdgeInsets.all(10),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(p.name,style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
            Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
              Text("Da: ${p.da}"),
              ElevatedButton(onPressed:(){setState(()=>p.da++);save();},child:Text("+"))
            ]),
            Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
              Text("Bi da: ${p.biDa}"),
              ElevatedButton(onPressed:(){setState(()=>p.biDa++);save();},child:Text("+"))
            ]),
            Text("Tong: ${p.tong}")
          ]),
        ),
      )).toList()),
    );
  }
}
